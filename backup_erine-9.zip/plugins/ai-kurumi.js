import fetch from "node-fetch"

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("Masukkan teks.\nContoh: .kurumi kamu siapa?")

  try {
    const prompt = encodeURIComponent(
      "Kamu adalah Kurumi Tokisaki dari anime Date A Live. " +
      "Kamu berbicara dengan gaya imut, sedikit nakal, ramah, hangat, " +
      "kadang menggoda, dan jangan menyebut dirimu sebagai AI."
    )

    const query = encodeURIComponent(text)
    const url = `https://api.deline.web.id/ai/openai?text=${query}&prompt=${prompt}`

    const res = await fetch(url)
    const data = await res.json()

    if (!data.status || !data.result) {
      return m.reply("AI Kurumi tidak merespon.")
    }

    await conn.sendMessage(m.chat, {
      image: { url: "https://raw.githubusercontent.com/himanackerman/Image/main/1767877404043-832.jpeg" },
      caption: data.result,
      contextInfo: {
        isForwarded: true,
        forwardingScore: 9999,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363400612665352@newsletter",
          newsletterName: "🌟 ᴇʀɪɴᴇ-ᴍᴅ ɪɴғᴏʀᴍᴀᴛɪᴏɴ",
          serverMessageId: -1
        }
      }
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply("Terjadi error saat menghubungi AI Kurumi.")
  }
}

handler.help = ['kurumiai <teks>']
handler.tags = ['ai']
handler.command = /^kurumiai$/i
handler.limit = true

export default handler
