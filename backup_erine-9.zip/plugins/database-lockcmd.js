// File: plugins/lockcmd.js
let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!m.quoted) throw 'Tag Pesan!'
    if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
    let sticker = global.db.data.sticker
    let hash = Buffer.from(m.quoted.fileSha256).toString('base64')
    if (!(hash in sticker)) throw 'Hash not found in database'
    sticker[hash].locked = !/^un/i.test(command)
    m.reply('Done!')
} 

handler.help = ['un', ''].map(v => v + 'lockcmd')
handler.tags = ['database']
handler.command = /^(un)?lockcmd$/i

export default handler